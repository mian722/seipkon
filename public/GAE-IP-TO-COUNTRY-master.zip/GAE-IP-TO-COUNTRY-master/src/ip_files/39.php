<?php
//654311424-671088639
$ranges=Array(
);
?>